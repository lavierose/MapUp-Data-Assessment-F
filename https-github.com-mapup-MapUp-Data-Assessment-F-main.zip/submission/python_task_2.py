import pandas as pd


def calculate_distance_matrix(df)->pd.DataFrame():
    """
    Calculate a distance matrix based on the dataframe, df.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame: Distance matrix
    """
    # Write your logic here
    import networkx as nx
df = pd.read_csv('dataset-2.csv')

def calculate_distance_matrix(dataframe):
G = nx.DiGraph()
for _, row in dataframe.iterrows():
    G.add_edge(row['toll_booth_A'], row['toll_booth_B'], distance=row['distance'])
    G.add_edge(row['toll_booth_B'], row['toll_booth_A'], distance=row['distance'])

distances = nx.floyd_warshall(G, weight='distance')
distance_matrix = pd.DataFrame(distances, index=G.nodes, columns=G.nodes)
distance_matrix.values[[range(distance_matrix.shape[0])]*2] = 0

return distance_matrix
result = calculate_distance_matrix(dataset_3)
print(result)

    return df


def unroll_distance_matrix(df)->pd.DataFrame():
    """
    Unroll a distance matrix to a DataFrame in the style of the initial dataset.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame: Unrolled DataFrame containing columns 'id_start', 'id_end', and 'distance'.
    """
    # Write your logic here
upper_triangle = distance_matrix.where(pd.notna(distance_matrix), 0).values
upper_triangle[np.tril_indices_from(upper_triangle)] = np.nan
 row_indices, col_indices = np.where(upper_triangle != 0)
 #Create a DataFrame with id_start, id_end, and distance columns
unrolled_df = pd.DataFrame({
    'id_start': distance_matrix.index[row_indices],
    'id_end': distance_matrix.columns[col_indices],
    'distance': upper_triangle[row_indices, col_indices]
})

return unrolled_df
unrolled_result = unroll_distance_matrix(result)
print(unrolled_result)


    return df


def find_ids_within_ten_percentage_threshold(df, reference_id)->pd.DataFrame():
    """
    Find all IDs whose average distance lies within 10% of the average distance of the reference ID.

    Args:
        df (pandas.DataFrame)
        reference_id (int)

    Returns:
        pandas.DataFrame: DataFrame with IDs whose average distance is within the specified percentage threshold
                          of the reference ID's average distance.
    """
    # Write your logic here
    def find_ids_within_ten_percentage_threshold(distance_df, reference_value):
reference_df = distance_df[distance_df['id_start'] == reference_value]
average_distance = reference_df['distance'].mean()
lower_bound = average_distance - (average_distance * 0.1)
upper_bound = average_distance + (average_distance * 0.1)
within_threshold_ids = distance_df[
    (distance_df['id_start'] != reference_value) &
    (distance_df['distance'] >= lower_bound) &
    (distance_df['distance'] <= upper_bound)
]['id_start'].unique()
sorted_within_threshold_ids = sorted(within_threshold_ids)

return sorted_within_threshold_ids
reference_value = 1 # Replace with the desired reference value
result = find_ids_within_ten_percentage_threshold(unrolled_result, reference_value)
print(result)


    return df


def calculate_toll_rate(df)->pd.DataFrame():
    """
    Calculate toll rates for each vehicle type based on the unrolled DataFrame.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame
    """
    # Wrie your logic here
    def calculate_toll_rate(distance_df):
rate_coefficients = {
'moto': 0.8,
'car': 1.2,
'rv': 1.5,
'bus': 2.2,
'truck': 3.6
}
for vehicle_type, rate in rate_coefficients.items():
    column_name = vehicle_type + '_toll'
    distance_df[column_name] = distance_df['distance'] * rate

return distance_df
result_with_toll_rates = calculate_toll_rate(unrolled_result)
print(result_with_toll_rates)


    return df


def calculate_time_based_toll_rates(df)->pd.DataFrame():
    """
    Calculate time-based toll rates for different time intervals within a day.

    Args:
        df (pandas.DataFrame)

    Returns:
        pandas.DataFrame
    """
    # Write your logic here
    import numpy as np
from datetime import datetime, time, timedelta

def calculate_time_based_toll_rates(input_df):
input_df['start_datetime'] = pd.to_datetime(input_df['startDay'] + ' ' + input_df['startTime'])
input_df['end_datetime'] = pd.to_datetime(input_df['endDay'] + ' ' + input_df['endTime'])
time_ranges_weekdays = [(time(0, 0), time(10, 0), 0.8),
                        (time(10, 0), time(18, 0), 1.2),
                        (time(18, 0), time(23, 59, 59), 0.8)]

time_ranges_weekends = [(time(0, 0), time(23, 59, 59), 0.7)]
for start_time, end_time, discount_factor in time_ranges_weekdays:
    mask = (input_df['start_datetime'].dt.time >= start_time) & (input_df['end_datetime'].dt.time <= end_time) & (input_df['start_datetime'].dt.dayofweek < 5)
    input_df.loc[mask, ['moto', 'car', 'rv', 'bus', 'truck']] *= discount_factor

for start_time, end_time, discount_factor in time_ranges_weekends:
    mask = (input_df['start_datetime'].dt.time >= start_time) & (input_df['end_datetime'].dt.time <= end_time)
    input_df.loc[mask, ['moto', 'car', 'rv', 'bus', 'truck']] *= discount_factor
input_df['start_day'] = input_df['start_datetime'].dt.strftime('%A')
input_df['start_time'] = input_df['start_datetime'].dt.time
input_df['end_day'] = input_df['end_datetime'].dt.strftime('%A')
input_df['end_time'] = input_df['end_datetime'].dt.time
input_df = input_df.drop(['start_datetime', 'end_datetime'], axis=1)
return input_df




    return df






